# Pocket TV — Android starter

This is a starter Android app that loads an M3U playlist from a raw GitHub HTTPS URL and plays supported HTTPS HLS/DASH/video URLs using AndroidX Media3.

## Safety and playback limits
- Use only streams you own or are authorized to access.
- The app does not configure DRM licenses, inject authentication headers, or bypass paywalls/access controls.
- Entries carrying `KODIPROP`, `license_key`, `license_type`, or `EXTHTTP` metadata are skipped.
- Only HTTPS stream URLs with `.m3u8`, `.mpd`, or `.mp4` in the URL are listed.
- Some legitimate streams may need a more complete M3U parser or may not play in this starter.

## 1. Create a GitHub repository
1. On GitHub, create a new repository named `PocketTV`.
2. Upload the files and folders from this project, preserving their paths.
3. Make sure `.github/workflows/build-apk.yml` is present at that exact path.

## 2. Set your playlist URL
Open `app/src/main/java/com/pockettv/MainActivity.kt`.
Find the `playlistUrl.setText(...)` line and replace the example URL with your own raw GitHub URL, for example:
`https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/playlist.m3u`

Your M3U should contain ordinary `#EXTINF` entries followed by HTTPS stream URLs that you are allowed to use. Do not add DRM keys or authentication-bypass metadata.

Raw GitHub URLs generally use:
`https://raw.githubusercontent.com/OWNER/REPOSITORY/BRANCH/PATH/FILE.m3u`

## 3. Build the APK online
1. Open your new repository on GitHub.
2. Open **Actions**.
3. Select **Build Pocket TV APK**.
4. Tap **Run workflow**, select `main`, then run it. A push to `main` also triggers a build.
5. Open the completed workflow run.
6. Under **Artifacts**, download `Pocket-TV-debug-APK`.
7. Extract the ZIP on your phone to get `app-debug.apk`.
8. Install only if you trust your own repository and the build. Android may ask you to allow installation from that source.

## Notes
- The first build may take several minutes.
- This is a debug APK for testing, not a Play Store release.
- If the build fails, open the workflow run and copy the first red error section so it can be diagnosed.
