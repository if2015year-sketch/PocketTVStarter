package com.pockettv

import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.URL
import java.net.HttpURLConnection
import java.util.Locale

data class Channel(val name: String, val url: String) {
    override fun toString(): String = name
}

class MainActivity : AppCompatActivity() {
    private lateinit var playlistUrl: EditText
    private lateinit var status: TextView
    private lateinit var playerView: PlayerView
    private lateinit var channelList: ListView
    private var player: ExoPlayer? = null
    private val channels = mutableListOf<Channel>()
    private lateinit var adapter: ArrayAdapter<Channel>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
            setBackgroundColor(Color.rgb(16, 21, 29))
        }

        val title = TextView(this).apply {
            text = "POCKET TV"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(title)

        playlistUrl = EditText(this).apply {
            hint = "HTTPS raw GitHub M3U playlist URL"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            textSize = 13f
            setSingleLine(true)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(35, 43, 55))
        }
        root.addView(playlistUrl, LinearLayout.LayoutParams(-1, dp(48)))

        val loadButton = Button(this).apply {
            text = "Load playlist from GitHub"
            setOnClickListener { loadPlaylist() }
        }
        root.addView(loadButton, LinearLayout.LayoutParams(-1, dp(48)))

        status = TextView(this).apply {
            text = "Paste a link to an M3U playlist you are authorized to use."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, dp(5))
        }
        root.addView(status)

        playerView = PlayerView(this).apply {
            useController = true
            setBackgroundColor(Color.BLACK)
        }
        root.addView(playerView, LinearLayout.LayoutParams(-1, dp(220)))

        val listHeading = TextView(this).apply {
            text = "CHANNELS"
            textSize = 14f
            setTextColor(Color.rgb(66, 211, 146))
            setPadding(0, dp(10), 0, dp(4))
        }
        root.addView(listHeading)

        channelList = ListView(this).apply {
            setBackgroundColor(Color.rgb(22, 29, 39))
            divider = android.graphics.drawable.ColorDrawable(Color.rgb(48, 58, 72))
            dividerHeight = dp(1)
        }
        adapter = object : ArrayAdapter<Channel>(
            this, android.R.layout.simple_list_item_1, channels
        ) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = super.getView(position, convertView, parent) as TextView
                row.setTextColor(Color.WHITE)
                row.setPadding(dp(12), dp(12), dp(8), dp(12))
                return row
            }
        }
        channelList.adapter = adapter
        channelList.setOnItemClickListener { _, _, position, _ -> playChannel(channels[position]) }
        root.addView(channelList, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
        playlistUrl.setText("https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/playlist.m3u")
        initPlayer()
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    status.text = "Playback failed. The stream may be offline, unsupported, or require authorization."
                }
            })
        }
    }

    private fun loadPlaylist() {
        val address = playlistUrl.text.toString().trim()
        if (!address.startsWith("https://", ignoreCase = true) ||
            !address.contains("raw.githubusercontent.com", ignoreCase = true)
        ) {
            status.text = "Use an HTTPS raw.githubusercontent.com link to your own authorized M3U file."
            return
        }

        status.text = "Loading playlist…"
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = URL(address).openConnection() as HttpURLConnection
                connection.connectTimeout = 12000
                connection.readTimeout = 12000
                connection.requestMethod = "GET"
                connection.setRequestProperty("User-Agent", "PocketTV/1.0")
                if (connection.responseCode !in 200..299) {
                    throw IllegalStateException("HTTP ${connection.responseCode}")
                }
                val content = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = parseM3u(content)
                runOnUiThread {
                    channels.clear()
                    channels.addAll(parsed)
                    adapter.notifyDataSetChanged()
                    status.text = "Loaded ${channels.size} playable-format entries. Only authorized streams will work."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Could not load playlist. Check the raw GitHub URL and internet connection."
                }
            } finally {
                connection?.disconnect()
            }
        }.start()
    }

    private fun parseM3u(text: String): List<Channel> {
        val result = mutableListOf<Channel>()
        var pendingName: String? = null
        var protectedEntry = false

        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                pendingName = line.substringAfter(',', "Unnamed channel").trim()
                    .ifBlank { "Unnamed channel" }
                protectedEntry = false
            } else if (
                line.contains("KODIPROP", ignoreCase = true) ||
                line.contains("license_key", ignoreCase = true) ||
                line.contains("license_type", ignoreCase = true) ||
                line.contains("EXTHTTP", ignoreCase = true)
            ) {
                protectedEntry = true
            } else if (!line.startsWith("#") && pendingName != null) {
                val isHttps = line.startsWith("https://", ignoreCase = true)
                val looksLikeStream = line.contains(".m3u8", true) ||
                    line.contains(".mpd", true) ||
                    line.contains(".mp4", true)
                if (!protectedEntry && isHttps && looksLikeStream) {
                    result.add(Channel(pendingName!!, line))
                }
                pendingName = null
                protectedEntry = false
            }
        }
        return result
    }

    private fun playChannel(channel: Channel) {
        try {
            val item = MediaItem.fromUri(channel.url)
            player?.setMediaItem(item)
            player?.prepare()
            player?.play()
            status.text = "Playing: ${channel.name}"
        } catch (e: Exception) {
            status.text = "This channel could not be played."
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
